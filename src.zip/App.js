import React from "react";
import Router from "./shared/Router";

export default function App() {
  return (
    <>
      <Router />
    </>
  );
}
